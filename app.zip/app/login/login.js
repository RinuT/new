'use strict';

angular.module('myApp.hospital', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/hospital', {
    templateUrl: 'hospital/hospital.html',
    controller: 'hospitalCtrl'
  });
}])

.controller('hospitalCtrl', ['$scope','$http','$timeout',function ($scope,$http,$timeout) {

   
}]);